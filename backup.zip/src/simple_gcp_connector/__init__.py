def hello() -> str:
    return "Hello from gcp-iam-db-auth!"
